#! /bin/sh

echo
echo "Please enter server"
read server_input
server=`grep ${server_input} ./stations`
echo "Loggining to ${server}"
echo
echo

cat passwd

echo
echo
ssh root@${server}
